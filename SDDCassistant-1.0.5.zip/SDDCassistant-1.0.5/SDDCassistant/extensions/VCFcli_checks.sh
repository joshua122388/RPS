#!/bin/bash
set -Eeuo pipefail



# Colors (optional)
YELLOW='\033[1;33m'
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

SCRIPT_NAME="VCFcli_checks.sh"
LOGFILE="/var/log/vcf_vxrail_health_check.log"

# Output file
OUTPUTDIR="/home/vcf"
OUTPUTFILE="${OUTPUTDIR}/CLIchecks_output.txt"

# Trap and logging
on_exit() {
  local rc=$?
  echo -e "\n===== Script ${SCRIPT_NAME} finished with exit code ${rc} at $(date) ====="
  exit "$rc"
}
trap on_exit EXIT

# Ensure we can write the log (usually requires root)
mkdir -p "$(dirname "$LOGFILE")"
touch "$LOGFILE" || { echo -e "${RED}ERROR: Cannot write to $LOGFILE. Run with sufficient privileges.${NC}"; exit 1; }
exec > >(tee -a "$LOGFILE") 2>&1

echo "===== VCF on VxRail CLI Check Script ====="
echo "Start Time: $(date)"
echo "============================================="

# Confirm action
echo "==========================================="
echo "VCF Technical Consultation CLI checks"
echo "==========================================="
read -rp "Do you want to start collecting the CLI checks now? (y/n): " confirm
if [[ "${confirm,,}" != "y" ]]; then
  echo -e "${YELLOW}Action cancelled by user.${NC}"
  exit 0
fi

# Prepare output file
mkdir -p "$OUTPUTDIR"
: > "$OUTPUTFILE" || { echo -e "${RED}ERROR: Cannot write to $OUTPUTFILE${NC}"; exit 1; }

# If running as root, give ownership back to vcf user if it exists
if id vcf >/dev/null 2>&1; then
  chown vcf:vcf "$OUTPUTFILE" || true
fi

# Helpers
require_cmd() {
  local cmd="$1"
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo -e "${YELLOW}WARN: Command not found: $cmd${NC}"
    return 1
  fi
}

append_section() {
  local title="$1"
  echo -e "\n--- ${title} ---"
  echo -e "\n[${title}]" >> "$OUTPUTFILE"
}

run_and_capture() {
  # Run a command; stream to OUTPUTFILE; report success/failure to console
  # Usage: run_and_capture "Description" command [args...]
  local desc="$1"; shift
  append_section "$desc"
  if "$@" >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}${desc} completed.${NC}"
    return 0
  else
    local rc=$?
    echo -e "${RED}${desc} failed (rc=${rc}). See $OUTPUTFILE for details.${NC}"
    return "$rc"
  fi
}

# 1. SOS version
if [[ -x /opt/vmware/sddc-support/sos ]]; then
  run_and_capture "SOS Version" /opt/vmware/sddc-support/sos --version || true
else
  append_section "SOS Version"
  echo "sos binary not found at /opt/vmware/sddc-support/sos" >> "$OUTPUTFILE"
  echo -e "${YELLOW}WARN: sos not found.${NC}"
fi

# 2. Workload Domain count from Postgres
append_section "Workload Domain Count"
QUERY="select d.type,count(distinct(d.name)) as wld_count from host_and_domain e,domain d where e.domain_id = d.id group by d.type order by wld_count;"

# Prefer running as postgres user if available (avoids password prompts)
if id postgres >/dev/null 2>&1; then
  if sudo -n -u postgres psql -d platform -c "$QUERY" >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}PostgreSQL query executed successfully as postgres user.${NC}"
  else
    echo -e "${YELLOW}Default postgres user invocation failed. Trying system psql as current user...${NC}"
    if command -v psql >/dev/null 2>&1 && psql --host=localhost -U postgres -d platform -c "$QUERY" >> "$OUTPUTFILE" 2>&1; then
      echo -e "${GREEN}PostgreSQL query executed successfully using system psql.${NC}"
    elif [[ -x /usr/pgsql/13/bin/psql ]] && /usr/pgsql/13/bin/psql --host=localhost -U postgres -d platform -c "$QUERY" >> "$OUTPUTFILE" 2>&1; then
      echo -e "${GREEN}PostgreSQL query executed successfully using fallback psql (PG 13).${NC}"
    else
      echo -e "${RED}Both PostgreSQL attempts failed. Verify auth (.pg_hba.conf) or run as postgres user.${NC}"
    fi
  fi
else
  # No postgres OS user; try psql in PATH then fallback
  if command -v psql >/dev/null 2>&1 && psql --host=localhost -U postgres -d platform -c "$QUERY" >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}PostgreSQL query executed successfully using system psql.${NC}"
  elif [[ -x /usr/pgsql/13/bin/psql ]] && /usr/pgsql/13/bin/psql --host=localhost -U postgres -d platform -c "$QUERY" >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}PostgreSQL query executed successfully using fallback psql (PG 13).${NC}"
  else
    echo -e "${RED}PostgreSQL queries failed. Install/authorize psql or run as postgres user.${NC}"
  fi
fi

# 3. LCM depot statuses (json_pp fallback)
append_section "LCM Depot Statuses"
JSONPP=""
if require_cmd json_pp; then
  JSONPP="json_pp"
elif command -v python3 >/dev/null 2>&1; then
  JSONPP="python3 -m json.tool"
fi

if [[ -n "$JSONPP" ]]; then
  if curl -s http://localhost/lcm/depot/statuses | $JSONPP >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}LCM depot status retrieved.${NC}"
  else
    echo -e "${RED}Failed to retrieve LCM depot status.${NC}"
  fi
else
  echo "No JSON pretty-printer found; writing raw response." >> "$OUTPUTFILE"
  if curl -s http://localhost/lcm/depot/statuses >> "$OUTPUTFILE" 2>&1; then
    echo -e "${GREEN}LCM depot status retrieved (raw).${NC}"
  else
    echo -e "${RED}Failed to retrieve LCM depot status.${NC}"
  fi
fi

# 4. Disk usage
run_and_capture "Disk Usage" df -h || true

# 5. SOS health check (run from sos dir to avoid import loader issues)
append_section "SOS Health Check"
if [[ -x /opt/vmware/sddc-support/sos ]]; then
  (
    cd /opt/vmware/sddc-support
    # Choose the user you know works; many environments require root
    if /opt/vmware/sddc-support/sos --health-check --domain-name ALL >> "$OUTPUTFILE" 2>&1; then
      echo -e "${GREEN}Health check completed.${NC}"
      exit 0
    else
      # Try alternative user if available
      if id vcf >/dev/null 2>&1; then
        if sudo -n -u vcf -E /opt/vmware/sddc-support/sos --health-check --domain-name ALL >> "$OUTPUTFILE" 2>&1; then
          echo -e "${GREEN}Health check completed as vcf user.${NC}"
          exit 0
        fi
      fi
      echo -e "${RED}Health check failed. See $OUTPUTFILE for Python traceback. Check dependency perms and working directory expectations.${NC}"
      exit 1
    fi
  )
else
  echo "sos binary not found at /opt/vmware/sddc-support/sos" >> "$OUTPUTFILE"
  echo -e "${YELLOW}WARN: sos not found; skipping health check.${NC}"
fi

# 6. VCF summary
run_and_capture "VCF Summary" /opt/vmware/sddc-support/sos --get-vcf-summary || true

echo -e "\n===== Script Completed at $(date) ====="
echo "All output saved to: $OUTPUTFILE"
``
