#!/bin/bash

clear -x

# Color codes
GREEN="\e[32m"
CYAN="\e[36m"
MAGENTA="\e[35m"
YELLOW="\e[33m"
RESET="\e[0m"
BOLD="\e[1m"

echo
echo -e "${BOLD}===================================================${RESET}"
echo -e "${GREEN}${BOLD}       VxRail: Offline bundle transfer for 8.0.390${RESET}"
echo -e "${BOLD}===================================================${RESET}"

echo -e "${MAGENTA}This script is designed to automate staging a VxRail Bundle. Before you run this script, you need to perform two tasks:${RESET}"
echo
echo "1. Download your VxRail bundle, rename it to J8C8F_VxRail-8.0.390-Composite-Upgrade-Slim-Package-for-8.0.x.zip"
echo "   and move it to /nfs/vmware/vcf/nfs-mount/bundle/"
echo
echo "2. Place vxrailPartnerBundleMetadata.json in /nfs/vmware/vcf/nfs-mount/bundle/"

# Variables
ZIP_FILE="/nfs/vmware/vcf/nfs-mount/bundle/J8C8F_VxRail-8.0.390-Composite-Upgrade-Slim-Package-for-8.0.x.zip"
JSON_FILE="/nfs/vmware/vcf/nfs-mount/bundle/vxrailPartnerBundleMetadata.json"
DEPOT_DIR="/nfs/vmware/vcf/nfs-mount/bundle/depot/local"
BUNDLES_DIR="$DEPOT_DIR/bundles"

# --- Confirmation prompt ---
echo
read -rp "$(echo -e "${CYAN}Have you completed the above two steps and are ready to proceed with staging? [Y/N]: ${RESET}")" ANSW
case "$ANSW" in
  [Yy]|[Yy][Ee][Ss])
    echo -e "${GREEN}Proceeding...${RESET}"
    ;;
  *)
    echo -e "${MAGENTA}Exiting. Please complete the two steps and re-run the script.${RESET}"
    exit 0
    ;;
esac

# --- Pre-flight: ZIP existence check ---
echo
if [[ ! -f "$ZIP_FILE" ]]; then
  echo -e "${MAGENTA}ERROR: Bundle not found: $ZIP_FILE${RESET}"
  echo -e "${CYAN}Please download, rename, and place the bundle in /nfs/vmware/vcf/nfs-mount/bundle/ then re-run.${RESET}"
  exit 1
fi
echo -e "${GREEN}Bundle file found.${RESET}"

# --- Pre-flight: JSON existence check ---
if [[ ! -f "$JSON_FILE" ]]; then
  echo -e "${MAGENTA}ERROR: vxrailPartnerBundleMetadata.json not found in /nfs/vmware/vcf/nfs-mount/bundle/${RESET}"
  echo -e "${CYAN}Please place the file there and re-run this script.${RESET}"
  exit 1
fi

# --- JSON age check ---
FILE_AGE_DAYS=$(( ( $(date +%s) - $(stat -c %Y "$JSON_FILE") ) / 86400 ))
if (( FILE_AGE_DAYS > 30 )); then
  echo
  echo -e "${YELLOW}WARNING: vxrailPartnerBundleMetadata.json is ${FILE_AGE_DAYS} days old (last modified: $(stat -c %y "$JSON_FILE" | cut -d' ' -f1)).${RESET}"
  echo -e "${CYAN}It is recommended to use a fresh copy of vxrailPartnerBundleMetadata.json.${RESET}"
  echo -e "${CYAN}Please upload a new vxrailPartnerBundleMetadata.json to /nfs/vmware/vcf/nfs-mount/bundle/ in another session.${RESET}"
  echo
  read -rp "$(echo -e "${BOLD}Press Enter once you have uploaded the new file, or type 'skip' to continue with the existing file: ${RESET}")" json_reply
  if [[ "${json_reply,,}" != "skip" ]]; then
    if [[ ! -f "$JSON_FILE" ]]; then
      echo -e "${MAGENTA}ERROR: vxrailPartnerBundleMetadata.json not found after upload. Aborting.${RESET}"
      exit 1
    fi
    echo -e "${GREEN}vxrailPartnerBundleMetadata.json detected. Continuing...${RESET}"
  else
    echo -e "${YELLOW}Continuing with existing file.${RESET}"
  fi
else
  echo -e "${GREEN}vxrailPartnerBundleMetadata.json found (${FILE_AGE_DAYS} days old).${RESET}"
fi

echo
echo -e "${BOLD}1. Updating permissions and ownership...${RESET}"
chmod 777 "$ZIP_FILE"
chown vcf_lcm:vcf "$ZIP_FILE"

chmod 777 "$JSON_FILE"
chown vcf_lcm:vcf "$JSON_FILE"

echo
echo -e "${BOLD}2. Copying bundle and metadata files...${RESET}"
cp -p /nfs/vmware/vcf/nfs-mount/bundle/*.json "$DEPOT_DIR/"
cp -p "$ZIP_FILE" "$BUNDLES_DIR/"

echo
echo -e "${BOLD}3. Updating permissions recursively for depot directory...${RESET}"
chmod -R 777 "$DEPOT_DIR"
chown -R vcf_lcm:vcf "$DEPOT_DIR"

echo
echo -e "${BOLD}Triggering LCM uploads via API...${RESET}"

HTTP_CODE=$(curl -s -o /tmp/lcm_curl_out.txt -w "%{http_code}" \
  -X PUT http://localhost/lcm/bundle/upload/partnerBundleMetadata \
  -H "Content-Type: application/json")
if [[ "$HTTP_CODE" =~ ^2 ]]; then
  echo -e "${GREEN}partnerBundleMetadata upload accepted (HTTP $HTTP_CODE).${RESET}"
else
  echo -e "${MAGENTA}WARNING: partnerBundleMetadata upload returned HTTP $HTTP_CODE.${RESET}"
  cat /tmp/lcm_curl_out.txt
fi

HTTP_CODE=$(curl -s -o /tmp/lcm_curl_out.txt -w "%{http_code}" \
  -X PUT http://localhost/lcm/bundle/upload/partnerBundle/VXRAIL8-0-390-29701531J8C8F_VxRail-8-0-390-Composite-Upgrade-Slim-Package-for-8-0-x-zip \
  -H "Content-Type: application/json")
if [[ "$HTTP_CODE" =~ ^2 ]]; then
  echo -e "${GREEN}partnerBundle upload accepted (HTTP $HTTP_CODE).${RESET}"
else
  echo -e "${MAGENTA}WARNING: partnerBundle upload returned HTTP $HTTP_CODE.${RESET}"
  cat /tmp/lcm_curl_out.txt
fi

echo
