
#!/bin/bash

echo "================================================================"
echo -e "\e[35mRemember to take a snapshot of your SDDC Manager before editing the DB\e[0m"
echo "================================================================"



# Define PostgreSQL username
PGUSER="postgres"

# Define SQL commands
VXRAIL_SQL="UPDATE vx_manager SET status='ACTIVE' WHERE status='ERROR';"
VCENTER_SQL="UPDATE vcenter SET status='ACTIVE' WHERE status='ERROR';"
NSX_SQL="UPDATE nsxt SET status='ACTIVE' WHERE status='ERROR';"

# Define SELECT commands
VXRAIL_SELECT="SELECT id, vm_name, status FROM vx_manager;"
VCENTER_SELECT="SELECT id, vm_name, status FROM vcenter;"
NSX_SELECT="SELECT id, cluster_fqdn, status FROM nsxt;"


# Function to run SQL command
run_sql() {
    local sql="$1"
    echo "$sql" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
    if [ $? -eq 0 ]; then
        echo
        echo -e "\e[32m✅ Update successful.\e[0m"  # Green
        echo "Command used:"
        echo "$sql"
    else
        echo
        echo -e "\e[31m❌ Update failed.\e[0m"       # Red
    fi
}

# Try default psql
PSQL_CMD="psql"
echo "\\q" | $PSQL_CMD --host=localhost -U "$PGUSER" &>/dev/null
if [ $? -ne 0 ]; then
    echo
    PSQL_CMD="/usr/pgsql/13/bin/psql"
    echo "\\q" | $PSQL_CMD -h localhost -U "$PGUSER" &>/dev/null
    if [ $? -ne 0 ]; then
        echo
        echo "❌ Failed to connect to the database using both methods."
        exit 1
    fi
fi

# Display SELECT command results
echo -e "\e[36m📋 Current status check queries:\e[0m"
echo
echo -e "\e[32m1.🔍  VxRail Manager Status:\e[0m"
echo "$VXRAIL_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo
echo -e "\e[37m2.🔍  vCenter Status:\e[0m"
echo "$VCENTER_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo
echo -e "\e[38;5;208m3.🔍  NSX Status:\e[0m"
echo "$NSX_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo
echo "================================================================"
echo

# Present menu
echo -e "\e[35m🛠️  Update your failed component status here!\e[0m"  # Bold green
echo
echo "Select an option:"
echo
echo -e "\e[32m1. Update VxRail manager status\e[0m"  # Green
echo -e "\e[37m2. Update vCenter status\e[0m"         # White
echo -e "\e[38;5;208m3. Update NSX status\e[0m"        # Orange (using 256-color code)
echo
read -p "Enter your choice (1-3): " choice
echo
case $choice in
    1)
        run_sql "$VXRAIL_SQL"
        ;;
    2)
        run_sql "$VCENTER_SQL"
        ;;
    3)
        run_sql "$NSX_SQL"
        ;;
    *)
        echo "❌ Invalid choice. Exiting."
        exit 1
        ;;
esac


# Display SELECT command results
echo "================================================================"
echo -e "\e[35m📋 New status check queries:\e[0m"
echo
echo -e "\e[32m1.🔍  VxRail Manager Status:\e[0m"
echo "$VXRAIL_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo
echo -e "\e[37m2.🔍  vCenter Status:\e[0m"
echo "$VCENTER_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo
echo -e "\e[38;5;208m3.🔍  NSX Status:\e[0m"
echo "$NSX_SELECT" | $PSQL_CMD -h localhost -U "$PGUSER" -d platform
echo

echo "================================================================"
echo

echo -e "\e[32mThe lcm service will need to be restarted to sync up the database entry change:\e[0m"

echo
read -p "Do you want to restart the LCM service? (y/n): " RETURN
if [[ "$RETURN" =~ ^[Yy]$ ]]; then
    echo "Restarting LCM service..."
    sudo systemctl restart lcm
    if [[ $? -eq 0 ]]; then
        echo "LCM service restarted successfully."
    else
        echo "Failed to restart LCM service."
    fi
else
    echo "Exiting script."
    exit 0
fi

# ✅ Add option to return to main menu
echo
read -p "Do you want to return to the main menu? (y/n): " RETURN
if [[ "$RETURN" =~ ^[Yy]$ ]]; then
    bash /home/vcf/SDDCassistant/SDDCAssistant.sh
else
    echo "Exiting script."
    exit 0
fi

