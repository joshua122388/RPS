#!/bin/bash

# Title: Log Collection Script for VCF on VxRail
# Description: Collects SDDC Manager logs and zips them using SOS utility.

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

#Clean screen
clear -x

echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}        VCF on VxRail - Log Collection ${NC}"
echo -e "${BLUE}========================================${NC}"

# Confirm action
read -p "Do you want to collect SDDC Manager logs now? (y/n): " confirm
if [[ "$confirm" != "y" ]]; then
    echo -e "${YELLOW}Action cancelled by user.${NC}"
    exit 0
fi

# Start log collection
echo -e "${YELLOW}Collecting logs... Please wait.${NC}"
/opt/vmware/sddc-support/sos --sddc-manager-logs --zip

# Check exit status
if [ $? -eq 0 ]; then
    echo -e "${GREEN}Log collection completed successfully!${NC}"
    echo -e "${BLUE}Logs are zipped and ready for download.${NC}"
else
    echo -e "${RED}Log collection failed. Please check the SOS tool or permissions.${NC}"
fi

echo -e "${BLUE}========================================${NC}"
echo -e "${GREEN}        Process Finished               ${NC}"
echo -e "${BLUE}========================================${NC}"
