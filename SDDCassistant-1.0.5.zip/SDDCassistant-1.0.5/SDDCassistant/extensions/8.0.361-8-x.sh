#!/bin/bash

clear -x

# Color codes
GREEN="\e[32m"
CYAN="\e[36m"
MAGENTA="\e[35m"
RESET="\e[0m"
BOLD="\e[1m"

echo
echo -e "${BOLD}===================================================${RESET}"
echo -e "${GREEN}${BOLD}       VxRail: Offline bundle transfer for 8.0.361 for 8.0.x:.${RESET}"
echo -e "${BOLD}===================================================${RESET}"
echo

echo -e "${MAGENTA}This script is designed to automate staging a VxRail Bundle. Before you run this script, you need to perform Two tasks:${RESET}"
echo
echo "1. Download your VxRail bundle, rename your bundle to 678HH_VxRail-8.0.361-Composite-Upgrade-Slim-Package-for-8.0.x.zip"
echo "   And move the bundle to /nfs/vmware/vcf/nfs-mount/bundle"
echo
echo "2. Place the vxrailPartnerBundleMetadata.json to the directory /nfs/vmware/vcf/nfs-mount/bundle/"


# --- Confirmation prompt  ---
echo
read -rp "$(echo -e "${BOLD}${CYAN}Have you completed the above two steps and are ready to proceed with staging? [Y/N]: ${RESET}")" ANSW
case "$ANSW" in
  [Yy]|[Yy][Ee][Ss])
    echo -e "${GREEN}Proceeding with staging...${RESET}"
    ;;
  *)
    echo -e "${MAGENTA}Exiting. Please complete the two steps and re-run the script.${RESET}"
    exit 0
    ;;
esac
# --- End confirmation prompt ---


# Variables

ZIP_FILE="/nfs/vmware/vcf/nfs-mount/bundle/678HH_VxRail-8.0.361-Composite-Upgrade-Slim-Package-for-8.0.x.zip"
JSON_FILE="/nfs/vmware/vcf/nfs-mount/bundle/vxrailPartnerBundleMetadata.json"
DEPOT_DIR="/nfs/vmware/vcf/nfs-mount/bundle/depot/local"
BUNDLES_DIR="$DEPOT_DIR/bundles"

echo
echo -e "${GREEN}1. Updating permissions and ownership...${RESET}"
chmod 777 "$ZIP_FILE"
chown vcf_lcm:vcf "$ZIP_FILE"

chmod 777 "$JSON_FILE"
chown vcf_lcm:vcf "$JSON_FILE"

echo

echo -e "${GREEN}2. Copying bundle and metadata files...${RESET}"
cp -p /nfs/vmware/vcf/nfs-mount/bundle/*.json "$DEPOT_DIR/"
cp -p "$ZIP_FILE" "$BUNDLES_DIR/"

echo

echo -e "${GREEN}3. Updating permissions recursively for depot directory...${RESET}"
chmod -R 777 "$DEPOT_DIR"
chown -R vcf_lcm:vcf "$DEPOT_DIR"

echo

echo -e "${GREEN}Triggering LCM uploads via API...${RESET}"
curl -X PUT http://localhost/lcm/bundle/upload/partnerBundleMetadata \
     -H "Content-Type: application/json"

curl -X PUT http://localhost/lcm/bundle/upload/partnerBundle/VXRAIL8-0-361-29253789678HH_VxRail-8-0-361-Composite-Upgrade-Slim-Package-for-8-0-x-zip \
     -H "Content-Type: application/json"
echo





