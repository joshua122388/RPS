
#!/bin/bash

# Color codes
GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
MAGENTA="\033[1;35m"
RED="\033[1;31m"
RESET="\033[0m"

clear -x

echo -e "${GREEN}Check if there are any locks on the SDDC Manager.${RESET}\n"
echo -e "Related KB: ${CYAN}https://www.dell.com/support/kbdoc/en-us/000372938${RESET}\n"

# Run the query and capture output
LOCKS=$(/usr/pgsql/13/bin/psql -h localhost -U postgres -d platform -t -A -F"," -c "select id, locking_context, resource_type, status from lock")

# Check if any locks exist
if [ -z "$LOCKS" ]; then
    echo "No locks found."
else
    # Display locks with numbering
    echo "Available Locks:"
    echo "$LOCKS" | nl -w2 -s'. '

    # Prompt user to select a lock to delete
    read -p "Enter the number of the lock you want to delete: " CHOICE

    # Extract the selected line
    SELECTED=$(echo "$LOCKS" | sed -n "${CHOICE}p")
    LOCK_ID=$(echo "$SELECTED" | cut -d',' -f1)

    # Confirm deletion
    read -p "Are you sure you want to delete lock ID $LOCK_ID? (y/n): " CONFIRM
    if [[ "$CONFIRM" =~ ^[Yy]$ ]]; then
        /usr/pgsql/13/bin/psql -h localhost -U postgres -d platform -c "delete from lock where id='$LOCK_ID';"
        echo "Lock $LOCK_ID deleted."
    else
        echo "Deletion cancelled."
    fi
fi

# ✅ Add option to return to main menu
echo
read -p "Do you want to return to the main menu? (y/n): " RETURN
if [[ "$RETURN" =~ ^[Yy]$ ]]; then
    bash /home/vcf/SDDCassistant/SDDCAssistant.sh
else
    echo "Exiting script."
    exit 0
fi

