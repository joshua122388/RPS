#!/bin/bash

# Colors
GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
MAGENTA="\033[1;35m"
RESET="\033[0m"

clear
echo -e "${CYAN}=========================================${RESET}"
echo -e "${GREEN}      VCF on VxRail - Version Summary    ${RESET}"
echo -e "${CYAN}=========================================${RESET}"

echo 
echo "Loading versions ..."

# Run SOS command to get summary
summary_output=$(/opt/vmware/sddc-support/sos --get-vcf-summary)

# Extract versions using grep and awk
SDDC_VERSION=$(echo "$summary_output" | grep -i "SDDC Version" | awk -F':' '{print $2}' | xargs)
VCENTER_VERSION=$(echo "$summary_output" | grep -i "vCENTER Version" | awk -F':' '{print $2}' | xargs)
NSX_VERSION=$(echo "$summary_output" | grep -i "NSX Version" | awk -F':' '{print $2}' | xargs)
VXRAIL_VERSION=$(echo "$summary_output" | grep -i "VxRail Version" | awk -F':' '{print $2}' | xargs)
ESXI_VERSION=$(echo "$summary_output" | grep -i "Esxi Version" | awk -F':' '{print $2}' | xargs)

# Display results
echo -e "SDDC Version:    ${MAGENTA}$SDDC_VERSION${RESET}"
echo -e "vCenter Version: ${MAGENTA}$VCENTER_VERSION${RESET}"
echo -e "NSX Version:     ${MAGENTA}$NSX_VERSION${RESET}"
echo -e "VxRail Version:  ${MAGENTA}$VXRAIL_VERSION${RESET}"
echo -e "ESXi Version:    ${MAGENTA}$ESXI_VERSION${RESET}"

echo -e "${CYAN}=========================================${RESET}"
echo -e "${GREEN}Version summary collected successfully.${RESET}"
echo -e "${CYAN}=========================================${RESET}"




# Option to return to main menu
echo
read -p "Return to main menu? (y/n): " return_choice
if [[ "$return_choice" == "y" ]]; then
    bash /home/vcf/SDDCassistant/SDDCAssistant.sh
else
    echo -e "${YELLOW}Exiting.${RESET}"
    exit 0
fi

