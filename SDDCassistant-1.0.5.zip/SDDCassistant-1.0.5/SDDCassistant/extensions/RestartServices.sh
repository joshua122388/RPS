#!/bin/bash

# Color codes
GREEN="\e[32m"
CYAN="\e[36m"
MAGENTA="\e[35m"
RESET="\e[0m"
BOLD="\e[1m"

# Service commands
ALL_SERVICES="/opt/vmware/vcf/operationsmanager/scripts/cli/sddcmanager_restart_services.sh"
LCM="lcm"
DOMAINMANAGER="domainmanager"
OPSMANAGER="operationsmanager"
COMMONSVCS="commonsvcs"
UIAPP="sddc-manager-ui-app"

# Function to restart a systemd service
restart_service() {
    local service=$1
    echo -e "${MAGENTA}Are you sure you want to restart ${CYAN}${service}${MAGENTA}? (yes/no)${RESET}"
    read confirm
    if [[ "$confirm" == "yes" ]]; then
        echo -e "${CYAN}Restarting ${service}...${RESET}"
        systemctl restart "$service"
        if [[ $? -eq 0 ]]; then
            echo -e "${GREEN}${service} restarted successfully.${RESET}"
        else
            echo -e "${MAGENTA}Failed to restart ${service}. Check logs.${RESET}"
        fi
    else
        echo -e "${CYAN}Restart canceled for ${service}.${RESET}"
    fi
    echo ""
}

# Function to restart all services
restart_all() {
    echo -e "${MAGENTA}Are you sure you want to restart ALL services? (yes/no)${RESET}"
    read confirm
    if [[ "$confirm" == "yes" ]]; then
        echo -e "${CYAN}Restarting all services...${RESET}"
        bash "$ALL_SERVICES"
        if [[ $? -eq 0 ]]; then
            echo -e "${GREEN}All services restarted successfully.${RESET}"
        else
            echo -e "${MAGENTA}Failed to restart all services. Check logs.${RESET}"
        fi
    else
        echo -e "${CYAN}Restart canceled for all services.${RESET}"
    fi
    echo ""
}

# Menu loop
while true; do
    echo -e "${MAGENTA}========================================${RESET}"
    echo -e "${GREEN}${BOLD} VMware VCF Service Restart Menu${RESET}"
    echo -e "${MAGENTA}========================================${RESET}"
    echo -e "${CYAN}1) Restart ALL services${RESET}"
    echo -e "${CYAN}2) Restart LCM${RESET}"
    echo -e "${CYAN}3) Restart Domain Manager${RESET}"
    echo -e "${CYAN}4) Restart Operations Manager${RESET}"
    echo -e "${CYAN}5) Restart Common Services${RESET}"
    echo -e "${CYAN}6) Restart SDDC Manager UI App${RESET}"
    echo -e "${CYAN}7) Exit${RESET}"
    echo -e "${MAGENTA}========================================${RESET}"
    read -p "Choose an option [1-7]: " choice

    case $choice in
        1) restart_all ;;
        2) restart_service "$LCM" ;;
        3) restart_service "$DOMAINMANAGER" ;;
        4) restart_service "$OPSMANAGER" ;;
        5) restart_service "$COMMONSVCS" ;;
        6) restart_service "$UIAPP" ;;
        7) echo -e "${GREEN}Exiting...${RESET}"; exit 0 ;;
        *) echo -e "${MAGENTA}Invalid option. Please try again.${RESET}" ;;
    esac
done
