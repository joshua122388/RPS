#!/bin/bash

# Color codes with bold
GREEN="\e[1;32m"      # Bold Green
CYAN="\e[1;36m"       # Bold Cyan
MAGENTA="\e[1;35m"    # Bold Magenta
RESET="\e[0m"

#Clears Screen while keeping old output
clear -x

MAIN_MENU="/home/vcf/SDDCassistant/SDDCAssistant.sh"

# Functions for each health check
password_health() {
    echo -e "${CYAN}Running Password Health Check...${RESET}"
    /opt/vmware/sddc-support/sos --password-health --domain-name ALL
    echo -e "${GREEN}Password Health Check Completed.${RESET}\n"
}

services_health() {
    echo -e "${CYAN}Running Services Health Check...${RESET}"
    /opt/vmware/sddc-support/sos --services-health --domain-name ALL
    echo -e "${GREEN}Services Health Check Completed.${RESET}\n"
}

storage_health() {
    echo -e "${CYAN}Running vSAN and Storage Health Check...${RESET}"
    /opt/vmware/sddc-support/sos --storage-health --domain-name ALL
    echo -e "${GREEN}Storage Health Check Completed.${RESET}\n"
}

certificate_health() {
    echo -e "${CYAN}Running Certificate Health Check...${RESET}"
    /opt/vmware/sddc-support/sos --certificate-health --domain-name ALL
    echo -e "${GREEN}Certificate Health Check Completed.${RESET}\n"
}

depot_status() {
    echo -e "${CYAN}Checking Depot Service Status...${RESET}"
    curl -s http://localhost/lcm/depot/statuses | json_pp
    echo -e "${GREEN}Depot Service Status Retrieved.${RESET}\n"
}

overall_health() {
    echo -e "${CYAN}Running Overall Health Check...${RESET}"
    /opt/vmware/sddc-support/sos --health-check --domain-name ALL
    echo -e "${GREEN}Overall Health Check Completed.${RESET}\n"
}

return_main_menu() {
    echo -e "${MAGENTA}Returning to Main Menu...${RESET}"
    bash "$MAIN_MENU"
    exit 0
}

# Menu loop
while true; do
    echo -e "${MAGENTA}========================================${RESET}"
    echo -e "${GREEN} VMware VCF Health Check Menu${RESET}"
    echo -e "${MAGENTA}========================================${RESET}"
    echo -e "${CYAN}1) Password Health${RESET}"
    echo -e "${CYAN}2) Services Health${RESET}"
    echo -e "${CYAN}3) vSAN and Storage Health${RESET}"
    echo -e "${CYAN}4) Certificate Health${RESET}"
    echo -e "${CYAN}5) Check Depot Service${RESET}"
    echo -e "${CYAN}6) Overall Health Check${RESET}"
    echo -e "${CYAN}7) Return to Main Menu${RESET}"
    echo -e "${CYAN}8) Exit${RESET}"
    echo -e "${MAGENTA}========================================${RESET}"
    read -p "Choose an option [1-8]: " choice

    case $choice in
        1) password_health ;;
        2) services_health ;;
        3) storage_health ;;
        4) certificate_health ;;
        5) depot_status ;;
        6) overall_health ;;
        7) return_main_menu ;;
        8) echo -e "${GREEN}Exiting...${RESET}"; exit 0 ;;
        *) echo -e "${MAGENTA}Invalid option. Please try again.${RESET}" ;;
    esac
done

