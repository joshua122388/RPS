
#!/bin/bash

# Color codes
GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
MAGENTA="\033[1;35m"
RED="\033[1;31m"
RESET="\033[0m"

# Big and green message
echo -e "======================================"
echo -e "${GREEN}  Restart your upgrade from the CLI  ${RESET}"
echo -e "======================================"

# Step 1: Get cluster information
echo
echo "Clusters:"
mapfile -t cluster_info < <(/usr/pgsql/13/bin/psql -h localhost -U postgres -d platform -t -A -F '|' -c "SELECT vcenter.id, vcenter.vm_name, vcenter.vm_management_ip_address, cluster.id, cluster.name FROM vcenter JOIN cluster_and_vcenter on cluster_and_vcenter.vcenter_id=vcenter.id JOIN cluster on cluster_and_vcenter.cluster_id=cluster.id;")

# Check if any clusters were returned
if [ ${#cluster_info[@]} -eq 0 ]; then
    echo -e "${RED}No cluster information found.${RESET}"
    exit 1
fi

# Display options
for i in "${!cluster_info[@]}"; do
    IFS='|' read -r vc_id vc_name vc_ip cluster_id cluster_name <<< "${cluster_info[$i]}"
    echo -e "${GREEN}$((i+1)).${RESET} Cluster Name: ${YELLOW}$cluster_name${RESET} | VC Name: ${YELLOW}$vc_name${RESET} | VC IP: ${YELLOW}$vc_ip${RESET}"
done

# Step 2: Prompt for selection
echo -e "Select the Cluster you would like to restart ${GREEN}(1, 2, 3 etc):${RESET}"
read -p "> " selection

if ! [[ "$selection" =~ ^[0-9]+$ ]] || [ "$selection" -lt 1 ] || [ "$selection" -gt "${#cluster_info[@]}" ]; then
    echo -e "${RED}Invalid selection. Exiting.${RESET}"
    exit 1
fi

# Extract selected cluster info
IFS='|' read -r selected_vc_id selected_vc_name selected_vc_ip selected_cluster_id selected_cluster_name <<< "${cluster_info[$((selection-1))]}"

# Step 3: Confirm upgrade
echo
echo -e "**Are you sure you want to start an upgrade for '${YELLOW}$selected_cluster_name${RESET}'? (yes/no):"
read -p "> " confirm
if [[ "$confirm" != "yes" ]]; then
    echo -e "${RED}Upgrade cancelled.${RESET}"
    exit 0
fi

# Step 4: Gather required inputs
echo
read -sp "$(echo -e ${GREEN}Enter admin password:${RESET} ) " password
echo
read -p "$(echo -e ${GREEN}Enter Bundle ID:${RESET} ) " bundle_id

# Step 5: Trigger upgrade
echo
echo -e "${CYAN}Starting upgrade for cluster ${GREEN}'$selected_cluster_name'${CYAN}...${RESET}"
echo
curl -k http://localhost/lcm/upgrades -u "admin:$password" -X POST -H 'Content-Type:application/json' -d "{
    \"bundleType\":\"VXRAIL\",
    \"bundleId\":\"$bundle_id\",
    \"slaType\":\"SLOW\",
    \"upgradeNow\":true,
    \"vcenterIds\":[ \"$selected_vc_id\" ],
    \"userInputSpec\":{
        \"version\":1,
        \"userInputs\":[
            {
                \"bundleElementSoftwareType\":\"VXRAIL\",
                \"description\":\"Migration based upgrade\",
                \"userInputElements\":[
                    {
                        \"type\":\"StringList\",
                        \"label\":\"upgradeClusters\",
                        \"description\":\"List of Cluster ID for cluster to be upgraded.\",
                        \"value\":\"$selected_cluster_id\"
                    }
                ]
            }
        ]
    }
}"; echo


# --------------------------------------------------------------------
# Step 6 (NEW): Offer to monitor the upgrade from the CLI
# --------------------------------------------------------------------


# --------------------------------------------------------------------
# Step 6 (NEW): Offer to monitor the upgrade from the CLI
# --------------------------------------------------------------------
echo
echo -e "${MAGENTA}Would you like to monitor the upgrade from the CLI?${RESET}"
read -r -p "Enter Y to start monitoring (or press Enter to quit): " reply

# Treat empty input as "no"
if [[ -z "$reply" ]]; then
    echo -e "${YELLOW}Monitoring skipped. Exiting.${RESET}"
    exit 0
fi

if [[ "$reply" =~ ^[Yy]$ ]]; then
    # SQL to run
    watch -n 5 '/usr/pgsql/13/bin/psql -U postgres -h localhost -d lcm -c "SELECT to_char(activity_time, '\''MM-DD HH24:MI'\'') as time, upgrade_activity, upgrade_id FROM upgrade_activity_log order by id desc LIMIT 30;"'

    # Build psql command as an array to avoid quoting issues


else
    echo -e "${YELLOW}Monitoring skipped. Exiting.${RESET}"
    exit 0
fi

