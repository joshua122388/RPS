#!/bin/bash

# Color codes
GREEN="\e[32m"
CYAN="\e[36m"
MAGENTA="\e[35m"
RESET="\e[0m"
BOLD="\e[1m"

clear -x

COMPAT_FILE="/opt/vmware/vcf/lcm/lcm-app/conf/compatibility.flag"
ASSISTANT_SCRIPT="/home/vcf/SDDCassistant/SDDCAssistant.sh"

# Function to display current compatibility settings
view_settings() {
    echo -e "${CYAN}${BOLD}Current Compatibility Settings:${RESET}"
    cat "$COMPAT_FILE"
    echo ""
}

# Function to disable compatibility checks
disable_checks() {
    sed -i 's/vcf.compatibility.controllers.compatibilityCheckEnabled=true/vcf.compatibility.controllers.compatibilityCheckEnabled=false/g' "$COMPAT_FILE"
    echo -e "${MAGENTA}Compatibility checks have been DISABLED.${RESET}"
    echo -e "${CYAN}New setting:${RESET}"
    cat "$COMPAT_FILE"
    echo ""
}

# Function to enable compatibility checks
enable_checks() {
    sed -i 's/vcf.compatibility.controllers.compatibilityCheckEnabled=false/vcf.compatibility.controllers.compatibilityCheckEnabled=true/g' "$COMPAT_FILE"
    echo -e "${GREEN}Compatibility checks have been ENABLED.${RESET}"
    echo -e "${CYAN}New setting:${RESET}"
    cat "$COMPAT_FILE"
    echo ""
}

# Function to restart LCM
restart_lcm() {
    echo -e "${MAGENTA}${BOLD}LCM must be restarted for changes to take effect.${RESET}"
    read -p "Are you sure you want to restart LCM? (yes/no): " confirm
    if [[ "$confirm" == "yes" ]]; then
        echo -e "${GREEN}Restarting LCM service...${RESET}"
        systemctl restart lcm
        if [[ $? -eq 0 ]]; then
            echo -e "${GREEN}LCM restarted successfully.${RESET}"
        else
            echo -e "${MAGENTA}Failed to restart LCM. Please check logs.${RESET}"
        fi
    else
        echo -e "${CYAN}Restart canceled.${RESET}"
    fi
    echo ""
}

# Menu loop
while true; do
    echo -e "${MAGENTA}==============================${RESET}"
    echo -e "${GREEN}${BOLD} VMware VCF Compatibility Menu${RESET}"
    echo -e "${MAGENTA}==============================${RESET}"
    echo -e "${CYAN}1) View current settings${RESET}"
    echo -e "${CYAN}2) Disable compatibility checks${RESET}"
    echo -e "${CYAN}3) Enable compatibility checks${RESET}"
    echo -e "${CYAN}4) Restart LCM service${RESET}"
    echo -e "${CYAN}5) Return to SDDC Assistant${RESET}"
    echo -e "${CYAN}6) Exit${RESET}"
    echo -e "${MAGENTA}==============================${RESET}"
    read -p "Choose an option [1-6]: " choice

    case $choice in
        1) view_settings ;;
        2) disable_checks ;;
        3) enable_checks ;;
        4) restart_lcm ;;
        5) bash "$ASSISTANT_SCRIPT"; exit 0 ;;
        6) echo -e "${GREEN}Exiting...${RESET}"; exit 0 ;;
        *) echo -e "${MAGENTA}Invalid option. Please try again.${RESET}" ;;
    esac
done
