
# --------------------------------------------------------------------
# Step 6 (NEW): Offer to monitor the upgrade from the CLI
# --------------------------------------------------------------------
echo
echo -e "${MAGENTA}Would you like to monitor the upgrade from the CLI?${RESET}"
read -r -p "Enter Y to start monitoring (or press Enter to quit): " reply

# Treat empty input as "no"
if [[ -z "$reply" ]]; then
    echo -e "${YELLOW}Monitoring skipped. Exiting.${RESET}"
    exit 0
fi

if [[ "$reply" =~ ^[Yy]$ ]]; then
    # SQL to run
    watch -n 5 '/usr/pgsql/13/bin/psql -U postgres -h localhost -d lcm -c "SELECT to_char(activity_time, '\''MM-DD HH24:MI'\'') as time, upgrade_activity, upgrade_id FROM upgrade_activity_log order by id desc LIMIT 30;"'

    # Build psql command as an array to avoid quoting issues
    

else
    echo -e "${YELLOW}Monitoring skipped. Exiting.${RESET}"
    exit 0
fi

