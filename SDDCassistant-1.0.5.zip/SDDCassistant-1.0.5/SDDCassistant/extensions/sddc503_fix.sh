
#!/usr/bin/env bash
# --------------------------------------------------------------------
# SDDC Manager UI 503 Fix
# Truncate key logs and remove rotated/compressed archives.
# Reference: https://knowledge.broadcom.com/external/article/327184
# --------------------------------------------------------------------

# ==== Color codes (consistent ANSI) ====
BLUE="\033[34m"
GREEN="\033[32m"
CYAN="\033[36m"
MAGENTA="\033[35m"
RESET="\033[0m"
BOLD="\033[1m"
YELLOW="\033[33m"
RED="\033[31m"

# ==== Optional: clean up the screen (keeps scrollback) ====
clear -x

# ==== Banner ====
echo
echo "==============================================="
echo -e "${GREEN}${BOLD}SDDC Manager UI – 503 Service Unavailable${RESET}"
echo "==============================================="
echo

echo "When the SDDC GUI is not accesible, this is mainly due to the following directory being full. note{If this directory is below 60%, select no in the next option."

#df -h | grep '/dev/mapper/vg_system-lv_root'
#echo -e ${CYAN}df -h | grep '/dev/mapper/vg_system-lv_root'${RESET} 

echo -e "${BOLD}${CYAN}$(df -h | grep '/dev/mapper/vg_system-lv_root')${RESET}"
echo
echo -e "This fix automates the steps described in:"
echo -e "${BOLD}${CYAN}https://knowledge.broadcom.com/external/article/327184/${RESET}"
echo

# ==== Before running: snapshot confirmation ====
echo -e "${YELLOW}${BOLD}Before running:${RESET}"
echo "A snapshot of the SDDC Manager VM must be taken."
while true; do
  echo -e "Have you created one? ${BOLD}${YELLOW}(yes/no)${RESET}"
  read -r answer
  case "${answer,,}" in
    y|yes)
echo
      echo -e "${BOLD}${GREEN}Snapshot confirmed. Proceeding...${RESET}"
      break
      ;;
    n|no)
      echo -e "${RED}No snapshot taken. Aborting for safety.${RESET}"
      exit 1
      ;;
    *)
      echo -e "${RED}Please answer 'yes' or 'no'.${RESET}"
      ;;
  esac
done

# ==== Start ====
echo -e "${BOLD}${CYAN}Starting SDDC Manager 503 fix...${RESET}"
echo

# ---- Truncate live log files ----
echo -e "${BOLD}${MAGENTA}Truncating active logs...${RESET}"
echo > /var/log/messages
echo > /var/log/audit/audit.log
echo > /var/log/auth.log
echo > /var/log/nginx/error.log
echo > /var/log/nginx/access.log
echo -e "${BOLD}${GREEN}Finished truncating logs.${RESET}"
echo

# ---- Remove rotated/compressed logs ----
echo -e "${BOLD}${MAGENTA}Removing rotated/compressed logs...${RESET}"
rm -f /var/log/audit/audit.*.gz
rm -f /var/log/messages.*.gz
rm -f /var/log/auth.*.gz
rm -f /var/log/nginx/error.*.gz
rm -f /var/log/nginx/access.*.gz
echo -e "${BOLD}${GREEN}Finished removing compressed logs.${RESET}"
echo

# ==== Finish ====
echo -e "${BOLD}${GREEN}Cleanup complete.${RESET}"
echo
echo -e "To help prevent recurrence, review and apply the KB:"
echo -e "  ${BOLD}${CYAN}https://knowledge.broadcom.com/external/article/327184${RESET}"

