
#!/bin/bash

# Get the directory of this script (absolute path)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Color codes
GREEN="\033[1;32m"
CYAN="\033[1;36m"
YELLOW="\033[1;33m"
MAGENTA="\033[1;35m"
RED="\033[1;31m"
BRIGHT="\e[94m"
BOLD="\e[1;35m"
RESET="\033[0m"
BRIGHT_GREEN="\033[92m"

# Clean carriage return characters from all files in the current directory
#echo -e "${CYAN}Cleaning carriage return characters from all files...${RESET}"
find /home/vcf/SDDCassistant /home/vcf/SDDCassistant/extensions -type f -exec sed -i 's/\r$//' {} +
#echo -e "${GREEN}Cleanup complete.${RESET}"

# Make all subscripts in extensions executable
chmod +x "$SCRIPT_DIR/extensions/"*.sh

clear -x

# Master Script Menu
echo "========================================="
echo -e "${GREEN}       SDDC ASSISTANT TOOLBOX${RESET}"
echo "========================================="
echo -e "${BOLD}SNAPSHOT THE SDDC MANAGER VM BEFORE RUNNING THIS SCRIPT${RESET}"
echo
echo "Select a script to run:"
echo
echo -e "${CYAN}Technical Consultation Scripts:${RESET}"
echo -e "1. Run your TC CLI checks with one script         '${GREEN}VCFcli_checks.sh${RESET}'"

echo
echo -e "${MAGENTA}Upgrade assistance:${RESET}"
echo -e "2. Cancel the Upgrade in the SDDC.                '${GREEN}Cancelling_upgrade.sh${RESET}'                  https://www.dell.com/support/kbdoc/en-us/000182177 "
echo -e "3. Restart your VxRail upgrade from the CLI.      '${GREEN}RestartingUpgrade.sh${RESET}'                   https://www.dell.com/support/kbdoc/en-ie/000224436"
echo -e "4. Update your failed components in the SDDC.     '${GREEN}UpdateDBfix.sh${RESET}'                         https://www.dell.com/support/kbdoc/en-us/000383178"
echo -e "5. Monitor your Upgrade from the cli.             '${GREEN}Monitor_upgrade.sh${RESET}'                        "
echo
echo -e "${YELLOW}SDDC Issue's:${RESET}"
echo -e "6. Check for any locks on your SDDC Manager       '${GREEN}ReleasingLock.sh${RESET}'                       https://www.dell.com/support/kbdoc/en-in/000372938"

echo -e "7. Set the compatibility to True/False            '${GREEN}Compatibility_Check.sh${RESET}'                 https://knowledge.broadcom.com/external/article/323368/"

echo -e "8. Restart Services?                              '${GREEN}RestartingServices.sh${RESET}'                  https://www.dell.com/support/kbdoc/en-us/000372845"

echo

echo -e "${BRIGHT}Health Checks/ Diagnostics:${RESET}"
echo -e "9.  Perform a health check of components?         '${GREEN}HealthChecks.sh${RESET}'                        https://www.dell.com/support/kbdoc/en-us/000372845"
echo -e "10. Generate a Log Bundle?                        '${GREEN}log_collection.sh${RESET}'        "
echo -e "11. Get all version's?                            '${GREEN}get_version.sh${RESET}'        "
echo
echo -e "${BRIGHT_GREEN}VxRail Bundle Staging:${RESET}"
echo
echo -e "${BOLD}Upgrading from 7.x${RESET}"
echo -e "12.  Stage VxRail 8.0.370?                        '${CYAN}5DPKH_VXRAIL_COMPOSITE-SLIM-8.0.370-29422450_for_7.0.x.zip ${RESET}'"
echo -e "13.  Stage VxRail 8.0.361?                        '${CYAN}29GJN_VxRail-8.0.361-Composite-Upgrade-Slim-Package-for-7.0.x.zip${RESET}'"
echo -e "14.  Stage VxRail 8.0.331?                        '${CYAN}3WGH0_VxRail-8.0.331-Composite-Upgrade-Slim-Package-for-7.0.x.zip ${RESET}'"
echo -e "15.  Stage VxRail 8.0.322?                        '${CYAN}PWMMH_VxRail-8.0.322-Composite-Upgrade-Slim-Package-for-7.0.x.zip ${RESET}'"
echo -e "${BOLD}Upgrading from 8.x${RESET}"
echo -e "16.  Stage VxRail 8.0.370?                        '${CYAN}C375Y_VXRAIL_COMPOSITE-SLIM-8.0.370-29422450_for_8.0.x.zip${RESET}'"
echo -e "17.  Stage VxRail 8.0.331?                        '${CYAN}X0KG3_VxRail-8-0-331-Composite-Upgrade-Slim-Package-for-8.0.x.zip ${RESET}'"
echo -e "18.  Stage VxRail 8.0.322?                        '${CYAN}1MFHV_VxRail-8.0.322-Composite-Upgrade-Slim-Package-for-8.0.x.zip${RESET}'"
echo -e "19.  Stage VxRail 8.0.380?                        '${CYAN}7H9J9_VxRail-8.0.380-Composite-Upgrade-Slim-Package-for-8.0.x.zip${RESET}'"
echo -e "20.  Stage VxRail 8.0.390?                        '${CYAN}J8C8F_VxRail-8.0.390-Composite-Upgrade-Slim-Package-for-8.0.x.zip${RESET}'"
echo
echo

echo    "q.  Quit?"

echo

read -p "Enter your choice (1-20): " choice



case $choice in
    1)
        clear -x
        echo -e "Running ${GREEN}VCFcli_checks.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/VCFcli_checks.sh"
        ;;

    2)
        clear -x
        echo -e "Running ${GREEN}Cancelling_Upgrade.sh.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/Cancelling_upgrade.sh"
        ;;

    3)
        clear -x
        echo -e "Running ${GREEN}RestartingUpgrade.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/RestartingUpgrade.sh"
        ;;
    4)
        clear -x
        echo -e "Running ${GREEN}UpdateDBfix.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/UpdateDBfix.sh"
        ;;

    5)
        clear -x
        echo -e "Running ${GREEN}Monitor_upgrade.sh.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/Monitor_upgrade.sh"
        ;;

    6)
        clear -x
        echo -e "Running ${GREEN}ReleasingLock.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/ReleasingLock.sh"
        ;;


    7)
        clear -x
        echo -e "Running ${GREEN}Compatibility_Check.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/Compatibility_Check.sh"
        ;;


    8)    clear -x
        echo -e "Running ${GREEN}RestartServices.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/RestartServices.sh"
        ;;

    9)
        clear -x
        echo -e "Running ${GREEN}Health_check.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/HealthChecks.sh"
        ;;


    10)
        clear -x
        echo -e "Running ${GREEN}log_collection.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/log_collection.sh"
        ;;


    11)
        clear -x
        echo -e "Running ${GREEN}get_version.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/get_version.sh"
        ;;


    12)
        clear -x
        echo -e "Running ${GREEN}8.0.370-7-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.370-7-x.sh"
        ;;


    13)
        clear -x
        echo -e "Running ${GREEN}8.0.361.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.361.sh"
        ;;

    14)
        clear -x
        echo -e "Running ${GREEN}8.0.331-7-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.331-7-x.sh"
        ;;
    15)
        clear -x
        echo -e "Running ${GREEN}8.0.322-7-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.322-7-x.sh"
        ;;

    16)
        clear -x
        echo -e "Running ${GREEN}8.0.370.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.370.sh"
        ;;

    17)
        clear -x
        echo -e "Running ${GREEN}8.0.331-8-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.331-8-x.sh"
        ;;



    18)
        clear -x
        echo -e "Running ${GREEN}8.0.322-8-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.322-8-x.sh"
        ;;

    19)
        clear -x
        echo -e "Running ${GREEN}8.0.380-8-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.380-8-x.sh"
        ;;

    20)
        clear -x
        echo -e "Running ${GREEN}8.0.390-8-x.sh${RESET}..."
        bash "$SCRIPT_DIR/extensions/8.0.390-8-x.sh"
        ;;

        q|Q|0)
            echo "Exiting... Goodbye!"
            exit 0
            ;;


    *)
        echo -e "${RED}Invalid choice. Please select 1 to 20${RESET}"
        exit 1
        ;;
esac
