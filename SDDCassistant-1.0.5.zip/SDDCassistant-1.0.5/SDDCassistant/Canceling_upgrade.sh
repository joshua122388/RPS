
#!/usr/bin/env bash
# ------------------------------------------------------------
# Cancel SDDC Manager upgrade in LCM DB by marking it complete
# with SUCCESS or ERROR based on actual component versions.
# ------------------------------------------------------------

# ---- Colors ----
BLUE="\033[34m"; GREEN="\033[32m"; CYAN="\033[36m"; MAGENTA="\033[35m"
YELLOW="\033[33m"; RED="\033[31m"; BOLD="\033[1m"; RESET="\033[0m"

# ---- Postgres connection ----
PSQL_BIN="/usr/pgsql/13/bin/psql"
DB_NAME="lcm"
DB_HOST="localhost"
DB_USER="postgres"

# If the specific psql path doesn't exist, fall back to PATH
if [[ ! -x "$PSQL_BIN" ]]; then
  if command -v psql >/dev/null 2>&1; then
    PSQL_BIN="$(command -v psql)"
  else
    echo -e "${RED}psql not found at /usr/pgsql/13/bin/psql and not in PATH.${RESET}"
    echo -e "${YELLOW}Install PostgreSQL client or adjust PSQL_BIN path in this script.${RESET}"
    exit 1
  fi
fi

PSQL_OPTS=(-h "$DB_HOST" -U "$DB_USER" -d "$DB_NAME" -v ON_ERROR_STOP=1)

# ---- Check connection ----
if ! "$PSQL_BIN" "${PSQL_OPTS[@]}" -At -c 'SELECT 1;' >/dev/null 2>&1; then
  echo -e "${RED}Unable to connect to Postgres (host=$DB_HOST db=$DB_NAME user=$DB_USER).${RESET}"
  echo -e "${YELLOW}If authentication is required, export PGPASSWORD and re-run:${RESET}"
  echo -e "  ${BLUE}export PGPASSWORD='your_password'${RESET}"
  exit 1
fi

clear -x
echo -e "${GREEN}${BOLD}SDDC Manager – Cancel Upgrade (LCM DB)${RESET}"
echo "------------------------------------------------------------"
echo -e "This will connect to the ${BOLD}lcm${RESET} database and update an upgrade's status."
echo
echo -e "${BOLD}${CYAN}Step 1: Listing upgrades currently in progress...${RESET}"

# Fetch upgrades considered "in progress" (cover common spellings)
# You originally used: upgrade_status='INPROGRSS'; we'll include that spelling too.
mapfile -t UPGRADES < <(
  "$PSQL_BIN" "${PSQL_OPTS[@]}" -At -F '|' -c \
"SELECT upgrade_id, upgrade_status
   FROM upgrade
  WHERE UPPER(upgrade_status) IN ('IN_PROGRESS','INPROGRESS','INPROGRSS')
  ORDER BY upgrade_id;"
)

if (( ${#UPGRADES[@]} == 0 )); then
  echo -e "${YELLOW}No upgrades found with status IN_PROGRESS/INPROGRESS/INPROGRSS.${RESET}"
  echo -e "If you expect one, you can inspect directly via:"
  echo -e "  ${BLUE}$PSQL_BIN -h $DB_HOST -U $DB_USER -d $DB_NAME${RESET}  then:"
  echo -e "  ${BLUE}\\c lcm; SELECT upgrade_id, upgrade_status FROM upgrade;${RESET}"
  exit 0
fi

echo
echo -e "${BOLD}Upgrades in progress:${RESET}"
i=1
for row in "${UPGRADES[@]}"; do
  IFS='|' read -r UPG_ID UPG_STATUS <<< "$row"
  printf "  %2d) %s  [%s]\n" "$i" "$UPG_ID" "$UPG_STATUS"
  ((i++))
done

echo
read -rp "Enter the number of the upgrade you want to cancel: " pick
if ! [[ "$pick" =~ ^[0-9]+$ ]] || (( pick < 1 || pick > ${#UPGRADES[@]} )); then
  echo -e "${RED}Invalid selection.${RESET}"
  exit 1
fi

SELECTED="${UPGRADES[$((pick-1))]}"
IFS='|' read -r SELECTED_ID SELECTED_STATUS <<< "$SELECTED"

echo
echo -e "${CYAN}Selected upgrade:${RESET} ${BOLD}$SELECTED_ID${RESET}  [${SELECTED_STATUS}]"
echo
echo -e "${BOLD}Choose how to mark it:${RESET}"
echo -e "  1) ${GREEN}COMPLETED_WITH_SUCCESS${RESET}  (new version is reflected on NSX/vCenter/VxRail)"
echo -e "  2) ${RED}COMPLETED_WITH_ERROR${RESET}     (older version still present on NSX/vCenter/VxRail)"
echo
read -rp "Enter 1 or 2: " choice

case "$choice" in
  1)
    NEW_STATUS="COMPLETED_WITH_SUCCESS"
    ;;
  2)
    NEW_STATUS="COMPLETED_WITH_ERROR"
    ;;
  *)
    echo -e "${RED}Invalid choice.${RESET}"
    exit 1
    ;;
esac

echo
echo -e "${YELLOW}About to run:${RESET}"
echo
echo -e "  ${YELLOW}UPDATE upgrade SET upgrade_status='${NEW_STATUS}' WHERE upgrade_id='${SELECTED_ID}';${RESET}"
read -rp "Type 'yes' to proceed: " confirm
if [[ "${confirm,,}" != "yes" ]]; then
  echo -e "${RED}Aborted by user.${RESET}"
  exit 1
fi

# Apply the update
if "$PSQL_BIN" "${PSQL_OPTS[@]}" -c \
"UPDATE upgrade SET upgrade_status='${NEW_STATUS}' WHERE upgrade_id='${SELECTED_ID}';"; then
  echo -e "${GREEN}Update applied successfully.${RESET}"
else
  echo -e "${RED}Update failed.${RESET}"
  exit 1
fi

# Show the updated row
echo
echo -e "${CYAN}Verifying updated status...${RESET}"
"$PSQL_BIN" "${PSQL_OPTS[@]}" -c \
"SELECT upgrade_id, upgrade_status FROM upgrade WHERE upgrade_id='${SELECTED_ID}';"

echo
echo -e "${BOLD}${GREEN}Done.${RESET}"
echo -e "If needed, you can manually review with:"

